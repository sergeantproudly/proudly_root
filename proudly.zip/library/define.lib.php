<?php

// DATES AND TIME
define('MINUTE_IN_SEC',60);
define('HOUR_IN_SEC',3600);
define('DAY_IN_SEC',86400);
define('WEEK_IN_SEC',604800);

?>